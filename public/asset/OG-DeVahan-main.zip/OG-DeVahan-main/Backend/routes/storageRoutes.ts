// import express from 'express';
// const router = express.Router();
// import multer from 'multer';
// import { uploadStorage } from '../controllers/storageController.js';
// const upload = multer({ dest: 'uploads/' });

// router.post('/', upload.single('file'),  uploadStorage)
// router.get('/', )

// export default router;