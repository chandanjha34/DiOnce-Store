import express from 'express';
const router = express.Router();
import { Csignup, Clogin } from '../controllers/CustomerAuth';
import { Dsignup, Dlogin } from '../controllers/DealerAuth';
import { Slogin, Ssignup } from '../controllers/ServiceAuth';

router.post('/customer/signup',Csignup);
router.post('/customer/login',Clogin);

router.post('/dealer/signup',Dsignup);
router.post('/dealer/login',Dlogin);

router.post('/service/signup',Ssignup);
router.post('/service/login',Slogin);

export default router;
